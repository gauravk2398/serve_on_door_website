<!DOCTYPE html>
<html>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
  border-radius: 7px;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */


/* Float cancel and signup buttons and add an equal width */
 .signupbtn {
  margin-left: 150px;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
  background-color: tomato;
  width: 50%;
  margin-left: 350px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
   .signupbtn {
     width: 100%;
  }
}
</style>
<body>

<?php
$con=mysqli_connect("localhost","root","","serve");

// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";

if(isset($_POST['submit']))
{
 $nn=$_POST['name'];
   $sn=$_POST['num'];
    $en=$_POST['email'];
   $pn=$_POST['psw'];
    $ppn=$_POST['psw-repeat'];

  $res=mysqli_query($con, "INSERT INTO REGISTER(name,contact,email,pass,repass) VALUES('$nn','$sn','$en','$pn','$ppn')");
  $pass=password_hash($pn, PASSWORD_BCRYPT);
  $repass=password_hash($ppn, PASSWORD_BCRYPT);
  $emailquery="select * from register where email='$en'";
  $query=mysqli_query($con,$emailquery);
  $emailcount=mysqli_num_rows($query);
  if($emailcount>0){
    }else{
    if($pn===$ppn)
    {
     $insertquery="INSERT INTO REGISTER(name,contact,email,pass,repass) VALUES('$nn','$sn','$en','$pn','$ppn')";
    $iquery=mysqli_query($con,$insertquery);
    if($iquery){
      ?>
      <script>
        alert("inserted successfuly");
      </script>
      <?php
       }else{
      ?>
      <script>alert(" not inserted successfuly");
      </script>
      <?php
         }
        }
    else{
      echo "password not matching";
    }
  }

if($res)
{

  echo "data inserted successfuly";
} 

  else {
  
    echo "unsuccessfull data";
  
  
         }
         mysqli_close($con);
}
?>


<form action="" method="POST" style="border:1px solid #ccc">
  <div class="container">
    <h1 style="text-align: center;">Sign Up</h1>
  
    <label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" required>
 <label for="num"><b>Contact Number</b></label>
    <input type="text" placeholder="Enter Contact Number" name="num" required>
    
    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" required>
    
    <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>

    <div class="clearfix">
     <a href="login.html"> <button type="submit" name="submit" class="signupbtn"><b>Sign Up</b></button></a>
    </div>
  </div>
</form>
</body>
</html>
